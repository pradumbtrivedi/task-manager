# 📋 Task Manager - Full Stack Application

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Node Version](https://img.shields.io/badge/node-%3E%3D14.0.0-brightgreen)
![MongoDB](https://img.shields.io/badge/MongoDB-4.0%2B-green)
![Status](https://img.shields.io/badge/status-active-success)

A **modern, full-stack task management application** built with Node.js, Express, MongoDB, and vanilla JavaScript. This project demonstrates professional full-stack development practices with a beautiful dark theme UI, responsive design, and comprehensive REST API.

## 🚀 Live Demo

> [Coming Soon - Deploy to your server]

## 📸 Features Showcase

- ✨ **Modern Dark Theme UI** - Beautiful, eye-friendly dark mode interface
- 🔐 **User Authentication** - Secure JWT-based authentication with password hashing
- 📊 **Project Management** - Create and organize multiple projects
- ✅ **Task Management** - Create, edit, and delete tasks with priority levels
- 🎯 **Task Status Tracking** - Organize tasks in three columns (Pending, In Progress, Completed)
- 📱 **Fully Responsive** - Works perfectly on desktop, tablet, and mobile devices
- 🎨 **Stunning UI/UX** - Professional gradients, animations, and smooth transitions
- 🔄 **RESTful API** - Complete REST API for all operations
- 💾 **MongoDB Database** - Persistent data storage
- 📈 **Real-time Statistics** - Dashboard with project and task counts

## 🛠️ Tech Stack

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web framework
- **MongoDB** - NoSQL database
- **Mongoose** - MongoDB ODM
- **JWT** - Authentication
- **bcryptjs** - Password hashing
- **CORS** - Cross-origin support

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Advanced styling with gradients, animations, flexbox, grid
- **JavaScript (ES6+)** - Modern JavaScript
- **Fetch API** - HTTP client

## 📋 Project Overview

### What is Task Manager?

Task Manager is a comprehensive web application designed to help users organize and track their projects and tasks efficiently. Built as a full-stack learning project, it demonstrates all essential concepts in modern web development.

### Key Capabilities

1. **User Management**
   - Secure registration with password validation
   - Login with JWT authentication
   - Password strength checker
   - Secure session management

2. **Project Organization**
   - Create multiple projects
   - Add descriptions to projects
   - Edit project details
   - Delete projects and associated tasks
   - View all projects in sidebar

3. **Task Tracking**
   - Create tasks within projects
   - Set task priority (Low, Medium, High)
   - Track task status (Pending, In Progress, Completed)
   - Add due dates to tasks
   - Edit and delete tasks

4. **User Interface**
   - Dark theme for eye comfort
   - Kanban-style task board
   - Dashboard with statistics
   - Modal dialogs for forms
   - Smooth animations and transitions
   - Professional color scheme

## 🎓 Learning Outcomes

This project covers complete full-stack development curriculum:

### **Backend Development**
- ✅ REST API design and implementation
- ✅ Express.js routing and middleware
- ✅ MongoDB database design and queries
- ✅ User authentication with JWT
- ✅ Password security with bcryptjs
- ✅ Authorization and access control
- ✅ Error handling and validation

### **Frontend Development**
- ✅ HTML5 semantic markup
- ✅ CSS3 Grid and Flexbox layouts
- ✅ CSS animations and transitions
- ✅ Responsive design with media queries
- ✅ JavaScript DOM manipulation
- ✅ Fetch API and async/await
- ✅ Form validation and error handling
- ✅ Client-side routing

### **Full-Stack Concepts**
- ✅ MVC architecture
- ✅ API design principles
- ✅ Client-server communication
- ✅ State management
- ✅ Security best practices
- ✅ User experience design

## 📁 Project Structure

```
task-manager/
│
├── 📁 public/                    # Frontend files
│   ├── index.html                # HTML structure
│   ├── app.js                    # Frontend JavaScript
│   └── styles.css                # Dark theme CSS
│
├── server.js                     # Express server & API routes
├── package.json                  # Dependencies
├── .env.example                  # Environment variables template
│
├── README.md                     # Documentation
└── QUICKSTART.md                 # Quick start guide
```

## 🚀 Quick Start

### Prerequisites
- Node.js (v14+)
- MongoDB (local or Atlas)
- npm or yarn

### Installation

1. **Clone or download the project**
```bash
cd task-manager
```

2. **Install dependencies**
```bash
npm install
```

3. **Setup environment variables**
```bash
cp .env.example .env
```

Edit `.env`:
```env
MONGODB_URI=mongodb://localhost:27017/task-manager
JWT_SECRET=your-secret-key-change-this
PORT=5000
NODE_ENV=development
```

4. **Start MongoDB**
```bash
mongod
```

5. **Run the server**
```bash
npm run dev
```

6. **Open in browser**
```
http://localhost:5000
```

## 🔌 API Endpoints

### Authentication
```
POST   /api/auth/register          # Create new account
POST   /api/auth/login             # Login user
```

### Projects
```
POST   /api/projects               # Create project
GET    /api/projects               # Get all user projects
GET    /api/projects/:id           # Get specific project
PUT    /api/projects/:id           # Update project
DELETE /api/projects/:id           # Delete project
```

### Tasks
```
POST   /api/tasks                  # Create task
GET    /api/projects/:projectId/tasks    # Get project tasks
PUT    /api/tasks/:id              # Update task
DELETE /api/tasks/:id              # Delete task
```

## 📊 Database Schema

### User
```javascript
{
  _id: ObjectId,
  username: String (unique),
  email: String (unique),
  password: String (hashed),
  createdAt: Date
}
```

### Project
```javascript
{
  _id: ObjectId,
  name: String (required),
  description: String,
  owner: ObjectId (ref: User),
  createdAt: Date,
  updatedAt: Date
}
```

### Task
```javascript
{
  _id: ObjectId,
  title: String (required),
  description: String,
  project: ObjectId (ref: Project, required),
  owner: ObjectId (ref: User, required),
  status: String (pending, in-progress, completed),
  priority: String (low, medium, high),
  dueDate: Date,
  createdAt: Date,
  updatedAt: Date
}
```

## 🔐 Security Features

- ✅ **Password Hashing** - bcryptjs with salt rounds
- ✅ **JWT Authentication** - Secure token-based auth
- ✅ **Protected Routes** - Authorization middleware
- ✅ **Input Validation** - Server-side validation
- ✅ **CORS Protection** - Cross-origin resource sharing
- ✅ **Secure Headers** - Best practices implemented
- ✅ **Password Strength** - Validation requirements

## 🎨 UI/UX Features

### Dark Theme Design
- 🌙 Eye-friendly dark background
- 🎨 Purple and pink gradient accents
- ✨ Smooth animations and transitions
- 💎 Professional shadows and depth
- 🌈 Color-coded priority levels

### Responsive Breakpoints
- **Mobile** (< 480px) - Optimized layout
- **Tablet** (480px - 1024px) - Adapted design
- **Desktop** (> 1024px) - Full features

### Animations
- Fade-in effects on page load
- Smooth hover transitions
- Slide animations on modals
- Glowing button effects
- Floating background elements

## 📝 Usage Example

### Register & Login
1. Click "Register" on login page
2. Enter username, email, password
3. Click "Create Account"
4. Automatically logged in

### Create Project
1. Click "+ New Project" in sidebar
2. Enter project name and description
3. Click "Create Project"
4. Project appears in sidebar

### Create Task
1. Select a project from sidebar
2. Click "+ Add Task"
3. Fill task details (title, description, priority, due date)
4. Click "Create Task"
5. Task appears in "Pending" column

### Manage Tasks
- **Edit**: Click "Edit" button on task
- **Change Status**: Edit task and select new status
- **Delete**: Click "Delete" button on task

## 🚧 Future Enhancements

- [ ] **Drag & Drop** - Move tasks between columns
- [ ] **Real-time Updates** - WebSocket for live collaboration
- [ ] **Team Features** - Share projects with team members
- [ ] **Task Comments** - Discussion threads on tasks
- [ ] **File Attachments** - Upload files to tasks
- [ ] **Search & Filter** - Advanced task searching
- [ ] **Export** - Export to PDF/CSV
- [ ] **Notifications** - Email/push notifications
- [ ] **Analytics** - Task completion analytics
- [ ] **Dark/Light Toggle** - Theme switcher
- [ ] **Mobile App** - React Native version
- [ ] **Recurring Tasks** - Repeating task support

## 🐛 Known Issues

- Currently no image/file upload support
- Single-user project access (no team features yet)
- No offline mode
- Limited to single browser session

## 🤝 Contributing

Contributions are welcome! Here's how:

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📚 Learning Resources

- [Express.js Documentation](https://expressjs.com/)
- [MongoDB Documentation](https://docs.mongodb.com/)
- [JWT Guide](https://jwt.io/)
- [MDN Web Docs](https://developer.mozilla.org/)
- [CSS Tricks](https://css-tricks.com/)
- [JavaScript Info](https://javascript.info/)

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 👨‍💻 Author

**Your Name / Your Team**
- GitHub: [@yourprofile](https://github.com/yourprofile)
- Email: your.email@example.com

## 🙏 Acknowledgments

- Thanks to the JavaScript community for amazing tools
- Inspired by modern productivity applications
- Built as a learning project for full-stack development

## 📞 Support

For support, email your.email@example.com or open an issue on GitHub.

---

## 🎯 Project Goals

This project was built to:
- ✅ Demonstrate full-stack development skills
- ✅ Implement best practices in web development
- ✅ Create a user-friendly productivity application
- ✅ Learn modern JavaScript frameworks and libraries
- ✅ Practice database design and management
- ✅ Build a professional UI/UX experience

## 📈 Project Statistics

- **Lines of Code**: 2000+
- **API Endpoints**: 14+
- **Frontend Components**: 20+
- **CSS Rules**: 2000+
- **Animations**: 10+
- **Development Time**: [Your time]

## 🔧 Configuration

### Environment Variables

```env
# MongoDB Configuration
MONGODB_URI=mongodb://localhost:27017/task-manager

# Authentication
JWT_SECRET=your-super-secret-key-change-this

# Server
PORT=5000
NODE_ENV=development

# CORS
CORS_ORIGIN=http://localhost:5000
```

### Available Scripts

```bash
npm run dev      # Start with nodemon (development)
npm start        # Start server (production)
npm install      # Install dependencies
npm test         # Run tests (if configured)
```

## 🎬 Getting Started Video

> [Coming Soon - YouTube tutorial link]

## ⭐ Show Your Support

Give a ⭐️ if this project helped you!

---

**Last Updated**: December 2024  
**Version**: 1.0.0  
**Status**: Active Development

