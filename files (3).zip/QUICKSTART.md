# Task Manager - Quick Start Guide

## ⚡ 5-Minute Setup

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Set Up Environment
```bash
cp .env.example .env
```

Edit `.env` and update:
```
MONGODB_URI=mongodb://localhost:27017/task-manager
JWT_SECRET=your-secret-key
```

### Step 3: Start MongoDB
```bash
# Local installation
mongod

# OR use MongoDB Atlas connection string in .env
```

### Step 4: Run Server
```bash
npm run dev
```

### Step 5: Open Application
```
http://localhost:5000
```

---

## 🧪 Test the Application

### Create Account
1. Click "Register"
2. Fill in details:
   - Username: `testuser`
   - Email: `test@example.com`
   - Password: `TestPass123!` (must be strong)
3. Click "Create Account"

### Create Project
1. Click "+ New Project"
2. Enter project name: `My First Project`
3. Add description (optional)
4. Click "Create Project"

### Create Task
1. Select your project
2. Click "+ Add Task"
3. Enter task details
4. Set priority and due date
5. Click "Create Task"

### Manage Tasks
- **Edit**: Click Edit button on task
- **Delete**: Click Delete button on task
- **Move Status**: Edit task and change status

---

## 📊 Project Features Overview

### Level 3: Advanced Features Included ✅

#### Task 6: Database Integration & User Authentication
- ✅ MongoDB database connection
- ✅ User registration & login
- ✅ Password hashing (bcryptjs)
- ✅ JWT token authentication
- ✅ Protected API endpoints
- ✅ Authorization checks

#### Task 5: API Integration & Front-End Interaction
- ✅ RESTful API (CRUD operations)
- ✅ Fetch API calls
- ✅ Async/await handling
- ✅ Error handling
- ✅ Dynamic data display
- ✅ Real-time UI updates

#### Task 3: Advanced CSS & Responsive Design
- ✅ CSS Grid & Flexbox layouts
- ✅ Animations & transitions
- ✅ CSS variables for theming
- ✅ Media queries (mobile, tablet, desktop)
- ✅ Advanced form styling
- ✅ Gradient backgrounds

#### Task 4: Form Validation & DOM Manipulation
- ✅ Client-side validation
- ✅ Password strength checker
- ✅ Email validation
- ✅ Dynamic form creation
- ✅ Modal interactions
- ✅ Error messages
- ✅ Client-side routing

---

## 🏗️ Project Architecture

```
User Interface (HTML/CSS/JS)
         ↓
   Fetch API
         ↓
Express.js API Routes
         ↓
Middleware (Auth/Validation)
         ↓
MongoDB Database
```

---

## 🔑 Default Credentials (for testing)

After registration, use these to test:
- Email: `your@email.com`
- Password: `Your@Password123`

---

## ⚙️ API Examples

### Register User
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "TestPass123!",
    "confirmPassword": "TestPass123!"
  }'
```

### Login
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "TestPass123!"
  }'
```

### Create Project
```bash
curl -X POST http://localhost:5000/api/projects \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "name": "My Project",
    "description": "Project description"
  }'
```

---

## 🐛 Common Issues & Solutions

| Issue | Solution |
|-------|----------|
| **MongoDB connection failed** | Start MongoDB: `mongod` |
| **Port 5000 in use** | Change PORT in .env or kill process |
| **Cannot login** | Check database connection |
| **CORS error** | Verify CORS_ORIGIN in .env matches frontend URL |
| **Tasks not loading** | Check browser console for API errors |

---

## 📱 Responsive Breakpoints

- **Mobile**: < 480px
- **Tablet**: 480px - 1024px
- **Desktop**: > 1024px

Test responsiveness by resizing browser or using DevTools.

---

## 🎯 Next Steps

1. **Customize colors**: Edit `:root` variables in `styles.css`
2. **Add more features**: Task comments, file uploads, sharing
3. **Deploy**: Use Heroku, Vercel, or AWS
4. **Add testing**: Jest for unit tests
5. **Optimize**: Add caching, compression, CDN

---

## 📞 Support

For issues:
1. Check browser console (F12) for errors
2. Check server logs
3. Review README.md for detailed info
4. Check MongoDB connection

---

**You're all set! Happy coding! 🚀**
