# Task Manager - Full Stack Development Project

A complete full-stack task/project management application built with Node.js, Express, MongoDB, and vanilla JavaScript. This project demonstrates all the key concepts from the full stack development curriculum including advanced CSS, responsive design, form validation, API integration, database integration, and user authentication.

## 📋 Project Overview

This task management tool allows users to:
- **Create and manage projects** with descriptions
- **Create and organize tasks** within projects
- **Track task status** (Pending, In Progress, Completed)
- **Set task priorities** (Low, Medium, High)
- **User authentication** with secure password handling
- **Responsive design** that works on desktop, tablet, and mobile

## 🎓 Learning Objectives Covered

### Task 3: Advanced CSS Styling and Responsive Design
- ✅ Complex layouts with CSS Grid and Flexbox
- ✅ CSS transitions and animations
- ✅ CSS variables for theming
- ✅ Responsive design with media queries
- ✅ Mobile-first approach
- ✅ Advanced form styling

### Task 4: Complex Form Validation and Dynamic DOM Manipulation
- ✅ Client-side form validation
- ✅ Password strength checker
- ✅ Email validation
- ✅ Dynamic DOM element creation
- ✅ Real-time feedback for users
- ✅ Modal interactions
- ✅ Client-side routing

### Task 5: API Integration and Front-End Interaction
- ✅ RESTful API endpoints (CRUD operations)
- ✅ Fetch API for server communication
- ✅ Async/await for handling API calls
- ✅ Error handling and user feedback
- ✅ Loading states and transitions
- ✅ Data binding between UI and API

### Task 6: Database Integration and User Authentication
- ✅ MongoDB database integration
- ✅ User authentication with JWT tokens
- ✅ Password hashing with bcryptjs
- ✅ Protected API endpoints
- ✅ Authorization checks
- ✅ User sessions management

## 📁 Project Structure

```
task-manager/
├── server.js              # Express server & API routes
├── app.js                 # Frontend JavaScript (API integration, DOM manipulation)
├── index.html             # HTML structure
├── styles.css             # Advanced CSS with animations
├── package.json           # Dependencies
├── .env.example          # Environment variables template
└── public/               # Static files directory (optional)
```

## 🚀 Quick Start Guide

### Prerequisites
- Node.js (v14 or higher)
- MongoDB (local or Atlas cloud)
- npm or yarn

### Installation

1. **Clone or extract the project**
```bash
cd task-manager
```

2. **Install dependencies**
```bash
npm install
```

3. **Configure environment variables**
```bash
# Copy the example file
cp .env.example .env

# Edit .env with your configuration
# Update MONGODB_URI and JWT_SECRET
```

4. **Start MongoDB**
```bash
# For local MongoDB
mongod

# OR use MongoDB Atlas connection string in .env
```

5. **Start the server**
```bash
# Development mode with auto-reload
npm run dev

# OR production mode
npm start
```

6. **Open the application**
```
http://localhost:5000
```

## 🔑 API Endpoints

### Authentication
- `POST /api/auth/register` - Create new user account
- `POST /api/auth/login` - Login user

### Projects
- `POST /api/projects` - Create new project
- `GET /api/projects` - Get all user projects
- `GET /api/projects/:id` - Get specific project
- `PUT /api/projects/:id` - Update project
- `DELETE /api/projects/:id` - Delete project

### Tasks
- `POST /api/tasks` - Create new task
- `GET /api/projects/:projectId/tasks` - Get tasks for project
- `PUT /api/tasks/:id` - Update task
- `DELETE /api/tasks/:id` - Delete task

## 🔐 Authentication

The application uses JWT (JSON Web Tokens) for authentication:

1. **Registration**: Users create account with username, email, password
   - Passwords are hashed using bcryptjs
   - Password validation includes strength checking
   - Email format validation

2. **Login**: Users authenticate with email and password
   - Returns JWT token valid for 7 days
   - Token stored in localStorage
   - Automatic logout on token expiration

3. **Authorization**: Protected routes require valid JWT token
   - Token sent in Authorization header
   - Server verifies token before processing requests

## 📱 Features

### User Interface
- **Responsive Design** - Works on all screen sizes
- **Dark/Light Elements** - Professional color scheme
- **Smooth Animations** - Transitions and effects
- **Modal Dialogs** - For creating/editing items
- **Task Board** - Kanban-style task organization
- **Statistics Dashboard** - Project and task counts

### Form Validation
- Real-time password strength indicator
- Email format validation
- Required field checking
- Confirm password matching
- Custom validation messages

### Task Management
- Drag-ready interface (can be enhanced)
- Priority levels (Low, Medium, High)
- Status tracking (Pending, In Progress, Completed)
- Due date management
- Task descriptions
- Quick actions (Edit, Delete)

## 🛠️ Technologies Used

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web framework
- **MongoDB** - NoSQL database
- **Mongoose** - MongoDB object modeling
- **JWT** - Authentication tokens
- **bcryptjs** - Password hashing
- **CORS** - Cross-Origin Resource Sharing

### Frontend
- **HTML5** - Markup
- **CSS3** - Styling with Grid, Flexbox, animations
- **JavaScript (ES6+)** - Logic and interactivity
- **Fetch API** - Server communication

## 🔧 Configuration

### Environment Variables (.env)
```
MONGODB_URI=mongodb://localhost:27017/task-manager
JWT_SECRET=your-super-secret-key-change-this
PORT=5000
CORS_ORIGIN=http://localhost:3000
NODE_ENV=development
```

### MongoDB Connection
**Local:**
```
mongodb://localhost:27017/task-manager
```

**MongoDB Atlas (Cloud):**
```
mongodb+srv://username:password@cluster.mongodb.net/task-manager
```

## 📊 Database Schema

### User
```javascript
{
  _id: ObjectId,
  username: String (unique),
  email: String (unique),
  password: String (hashed),
  createdAt: Date
}
```

### Project
```javascript
{
  _id: ObjectId,
  name: String,
  description: String,
  owner: ObjectId (ref: User),
  createdAt: Date,
  updatedAt: Date
}
```

### Task
```javascript
{
  _id: ObjectId,
  title: String,
  description: String,
  project: ObjectId (ref: Project),
  owner: ObjectId (ref: User),
  status: String (pending, in-progress, completed),
  priority: String (low, medium, high),
  dueDate: Date,
  createdAt: Date,
  updatedAt: Date
}
```

## 🎨 CSS Features Implemented

### Responsive Design
- Mobile-first approach
- Media queries for all breakpoints (480px, 768px, 1024px+)
- Flexible Grid and Flexbox layouts
- Responsive typography

### Animations & Transitions
- Fade-in animations
- Slide animations
- Scale transformations
- Hover effects
- Smooth transitions (0.2s - 0.5s)

### Advanced Styling
- CSS variables for theming
- Gradient backgrounds
- Box shadows
- Border radius
- Custom scrollbar styling

## 🚧 Future Enhancements

1. **Drag & Drop**: Implement task dragging between columns
2. **Real-time Updates**: WebSocket for live collaboration
3. **Team Features**: Share projects with other users
4. **Task Comments**: Add discussion threads to tasks
5. **File Attachments**: Upload files to tasks
6. **Search & Filter**: Advanced task searching
7. **Export**: Export tasks to PDF/CSV
8. **Dark Mode**: Theme toggle
9. **Push Notifications**: Reminders and updates
10. **Mobile App**: React Native/Flutter version

## 🐛 Troubleshooting

### MongoDB Connection Error
- Ensure MongoDB is running: `mongod`
- Check MONGODB_URI in .env file
- Verify MongoDB is accessible

### CORS Errors
- Check CORS_ORIGIN in .env
- Frontend and backend must have correct origins
- Frontend typically: http://localhost:3000 (or wherever served from)

### JWT Token Errors
- Ensure JWT_SECRET is set in .env
- Check token expiration
- Clear localStorage and re-login

### Port Already in Use
- Change PORT in .env
- Or kill process: `lsof -ti:5000 | xargs kill -9`

## 📝 Example Test Data

### Test User
```
Email: test@example.com
Password: TestPass123!
```

## 📚 Learning Resources

- [Express Documentation](https://expressjs.com/)
- [MongoDB Documentation](https://docs.mongodb.com/)
- [JWT Documentation](https://jwt.io/)
- [MDN Web Docs](https://developer.mozilla.org/)
- [CSS Tricks](https://css-tricks.com/)

## 📄 License

This project is open source and available under the MIT License.

## 👤 Author

Your Name or Team Name

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

---

**Built with ❤️ as a Full Stack Development Learning Project**
